const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();

// Middleware CORS
app.use(cors());
app.use(express.json());

// Configuration MailDev
const transporter = nodemailer.createTransport({
  host: 'localhost',
  port: 1025,
  secure: false,
  ignoreTLS: true
});

// Route de santé
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Backend fonctionnel',
    timestamp: new Date().toISOString()
  });
});

// Route de test SMTP - CORRIGÉE
app.get('/api/test-smtp', async (req, res) => {
  try {
    await transporter.verify();
    res.json({ 
      success: true, 
      message: 'Connexion SMTP réussie à MailDev' 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Erreur SMTP: ' + error.message 
    });
  }
});

// Route pour envoyer email
app.post('/api/send-email', async (req, res) => {
  try {
    const { to, subject, text } = req.body;

    if (!to || !subject || !text) {
      return res.status(400).json({
        success: false,
        message: 'Tous les champs sont requis'
      });
    }

    const info = await transporter.sendMail({
      from: 'app@test.com',
      to: to,
      subject: subject,
      text: text,
      html: `<p>${text}</p>`
    });

    res.json({ 
      success: true, 
      message: 'Email envoyé avec succès',
      messageId: info.messageId 
    });

  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Erreur: ' + error.message 
    });
  }
});

// Route pour l'interface MailDev
app.get('/api/maildev-url', (req, res) => {
  res.json({ 
    webInterface: 'http://localhost:1080' 
  });
});

// Démarrer le serveur
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`🚀 Serveur backend sur http://localhost:${PORT}`);
  console.log(`📧 Test santé: http://localhost:${PORT}/api/health`);
  console.log(`🔧 Test SMTP: http://localhost:${PORT}/api/test-smtp`);
});